package libraryDesign.PO;

public class Clc2 {
	private String clcID1;
	private String clcID2;
	private String clcname2;
	public String getClcID1() {
		return clcID1;
	}
	public void setClcID1(String clcID1) {
		this.clcID1 = clcID1;
	}
	public String getClcID2() {
		return clcID2;
	}
	public void setClcID2(String clcID2) {
		this.clcID2 = clcID2;
	}
	public String getClcname2() {
		return clcname2;
	}
	public void setClcname2(String clcname2) {
		this.clcname2 = clcname2;
	}
}
