package libraryDesign.PO;

public class Clc1 {

	private String clcID1;
	private String clcname1;
	public String getClcID1() {
		return clcID1;
	}
	public void setClcID1(String clcID1) {
		this.clcID1 = clcID1;
	}
	public String getClcname1() {
		return clcname1;
	}
	public void setClcname1(String clcname1) {
		this.clcname1 = clcname1;
	}
	

}
